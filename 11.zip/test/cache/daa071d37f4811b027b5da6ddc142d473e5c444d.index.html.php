<?php
/* Smarty version 3.1.30, created on 2016-10-13 18:04:26
  from "D:\WWW\test\tpl\index.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57ff5c2a03a7e9_26139543',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd0d10693a032095de4f88f6bf3dd489291f655ce' => 
    array (
      0 => 'D:\\WWW\\test\\tpl\\index.html',
      1 => 1476353063,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_57ff5c2a03a7e9_26139543 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
<head>
    <meta charset="UTF-8">
    <title>Wo Ai Ni De  Mi Mi </title>
</head>
<body>
wanglijunwanglijun
</body>
</html><?php }
}
