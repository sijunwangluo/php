<?php
/* Smarty version 3.1.30, created on 2016-10-19 13:48:18
  from "D:\WWW\test\tpl\wanglijun.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58070922d0f760_85399941',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0579c40e68fea2c8a7ed63ad715a903838bed45e' => 
    array (
      0 => 'D:\\WWW\\test\\tpl\\wanglijun.html',
      1 => 1476855989,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58070922d0f760_85399941 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_modifier_capitalize')) require_once 'D:\\WWW\\smarty\\plugins\\modifier.capitalize.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
<?php echo smarty_modifier_capitalize($_smarty_tpl->tpl_vars['articletitle']->value);?>

</body>
</html><?php }
}
