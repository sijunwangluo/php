<?php
/* Smarty version 3.1.30, created on 2016-10-13 18:04:26
  from "D:\WWW\test\tpl\index.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57ff5c2a00eeb9_49624855',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd0d10693a032095de4f88f6bf3dd489291f655ce' => 
    array (
      0 => 'D:\\WWW\\test\\tpl\\index.html',
      1 => 1476353063,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57ff5c2a00eeb9_49624855 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_modifier_capitalize')) require_once 'D:\\WWW\\smarty\\plugins\\modifier.capitalize.php';
$_smarty_tpl->compiled->nocache_hash = '511657ff5c29c92e03_04542806';
?>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo smarty_modifier_capitalize($_smarty_tpl->tpl_vars['articletitle']->value);?>
</title>
</head>
<body>
<?php echo $_smarty_tpl->tpl_vars['arr']->value['ceshi']['name'];
echo $_smarty_tpl->tpl_vars['arr']->value['ceshi']['password'];?>

</body>
</html><?php }
}
