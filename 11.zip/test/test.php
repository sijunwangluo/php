<?php
require '../smarty/Smarty.class.php';
$smarty=new Smarty();
$smarty->left_delimiter="{";
$smarty->right_delimiter="}";
$smarty->compile_dir='template_c';
$smarty->template_dir='tpl';
$smarty->cache_dir='cache';
$smarty->caching=false;
$smarty->cache_lifetime=120;


define("CONSTANT", "Hello world.");
$smarty->assign('haoba',CONSTANT);
$smarty->assign("articletitle",'好开心');
$arr=array('ceshi'=>array('name'=>'wanglijun','password'=>md5('606060wlj')));
$smarty->assign('arr',$arr);

$smarty->display('wanglijun.html');


